import { Component  } from "react";

class AdminLogoutComponent extends Component
{
    render()
    {
        return(
            <div className="container">
                <p>Thank you for using our application</p>
            </div>
        );
    }
}

export default AdminLogoutComponent;
import { Component  } from "react";

class AdminHomePageComponent extends Component
{
    render()
    {
        return(
            <div>
                    {/* Masthead*/}
                    <header className="masthead" id="our-rooms-header">
                        <div className="container">
                            <div className="masthead-subheading">Please know more about our rooms below</div>
                            {/* <div className="masthead-heading text-uppercase">It's Nice To Meet You</div> */}
                        </div>
                    </header>
                </div>

        );
    }
}

export default AdminHomePageComponent; 
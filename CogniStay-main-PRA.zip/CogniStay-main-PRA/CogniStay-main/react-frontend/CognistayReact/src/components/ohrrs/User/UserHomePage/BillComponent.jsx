import React, { Component } from "react";

class BillComponent extends Component
{
    render() {
        return (
            <div>
                Bill Component
                Bill Component
                Bill Component
                Bill Component
                Bill Component
            </div>
            // <div>
            //     <div>
            //         {/* Masthead*/}
            //         <header className="masthead" id="our-rooms-header">
            //             <div className="container">
            //                 <div className="masthead-subheading">Please know more about our rooms below</div>
            //                 {/* <div className="masthead-heading text-uppercase">It's Nice To Meet You</div> */}
            //             </div>
            //         </header>
            //     </div>
            //     <div class="container" id="body-main">
            //         <div className="page-header">
            //             <h1 id="h1-bill">Invoice</h1>
            //         </div>
            //         <div className="container">
            //             <div className="row">
            //                 <div className="col-md-6 col-md-offset-3 body-main">
            //                     <div className="col-md-12">
            //                         <div className="row">
            //                             <div className="col-md-4"> <img className="img-bill" alt="Invoce Template" src="./img/logo_sm.png" /> </div>
            //                             <div className="col-md-8 text-right">
            //                                 <h4 style={{ color: '#F81D2D' }}><strong>Atlantis</strong></h4>
            //                                 <p>01-2/34, xyz estate</p>
            //                                 <p>1800-111-222</p>
            //                                 <p>atlantis@atlantis.com</p>
            //                             </div>
            //                         </div> <br />
            //                         <div className="row">
            //                             <div className="col-md-12 text-center">
            //                                 <h2>INVOICE</h2>
            //                                 <h5>Reference-number</h5>
            //                             </div>
            //                         </div> <br />
            //                         <div>
            //                             <table className="table ">
            //                                 <thead>
            //                                     <tr>
            //                                         <th>
            //                                             <h5>Description</h5>
            //                                         </th>
            //                                         <th>
            //                                             <h5>Amount</h5>
            //                                         </th>
            //                                     </tr>
            //                                 </thead>
            //                                 <tbody>
            //                                     <tr>
            //                                         <td className="col-md-9">Samsung Galaxy 8 64 GB</td>
            //                                         <td className="col-md-3"><i className="fas fa-rupee-sign" area-hidden="true" /> 50,000 </td>
            //                                     </tr>
            //                                     <tr>
            //                                         <td className="col-md-9">JBL Bluetooth Speaker</td>
            //                                         <td className="col-md-3"><i className="fas fa-rupee-sign" area-hidden="true" /> 5,200 </td>
            //                                     </tr>
            //                                     <tr>
            //                                         <td className="col-md-9">Apple Iphone 6s 16GB</td>
            //                                         <td className="col-md-3"><i className="fas fa-rupee-sign" area-hidden="true" /> 25,000 </td>
            //                                     </tr>
            //                                     <tr>
            //                                         <td className="col-md-9">MI Smartwatch 2</td>
            //                                         <td className="col-md-3"><i className="fas fa-rupee-sign" area-hidden="true" /> 2,200 </td>
            //                                     </tr>
            //                                     <tr>
            //                                         <td className="text-right">
            //                                             <p> <strong>SGST and CGST:</strong> </p>
            //                                             <p> <strong>Total Amount: </strong> </p>
            //                                             <p> <strong>Payable Amount: </strong> </p>
            //                                         </td>
            //                                         <td>
            //                                             <p> <strong><i className="fas fa-rupee-sign" area-hidden="true" /> 500 </strong> </p>
            //                                             <p> <strong><i className="fas fa-rupee-sign" area-hidden="true" /> 82,900</strong> </p>
            //                                             <p> <strong><i className="fas fa-rupee-sign" area-hidden="true" /> 79,900</strong> </p>
            //                                         </td>
            //                                     </tr>
            //                                     <tr style={{ color: '#F81D2D' }}>
            //                                         <td className="text-right">
            //                                             <h4><strong>Total:</strong></h4>
            //                                         </td>
            //                                         <td className="text-left">
            //                                             <h4><strong><i className="fas fa-rupee-sign" area-hidden="true" /> 79,900 </strong></h4>
            //                                         </td>
            //                                     </tr>
            //                                 </tbody>
            //                             </table>
            //                         </div>
            //                         <div>
            //                             <div className="col-md-12">
            //                                 <p><b>Date :</b> 6 June 2019</p> <br />
            //                                 <p><b>Signature</b></p>
            //                             </div>
            //                         </div>
            //                     </div>
            //                 </div>
            //             </div>
            //         </div>
            //     </div>
            // </div>
        );
    }
}

export default BillComponent;